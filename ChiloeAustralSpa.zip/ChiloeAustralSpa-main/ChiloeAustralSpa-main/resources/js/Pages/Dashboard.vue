<script setup>
import AppMain from '@/Layouts/AppMain.vue';
import { Head } from '@inertiajs/vue3'
</script>
<template>
  <Head title="Inicio"/>
  <AppMain>
    <div class="w-full bg-gradient-to-b p-6 flex flex-row items-center">
      <div class="max-w-4xl mx-auto bg-white p-6 rounded-2xl shadow-lg border border-blue-200">
        <h2 class="text-2xl font-bold text-blue-800 mb-8">🚀 Bienvenido al Inicio</h2>
        <p class="text-gray-700 mb-4">Aquí puedes gestionar todas las funcionalidades de tu aplicación.</p>
        <p class="text-gray-500 text-sm">Utiliza el menú lateral para navegar entre las diferentes secciones.</p>
        <p class="text-gray-500 text-sm">Próximamente gráficos aquí!</p>
      </div>
      <div class="max-w-4xl mx-auto bg-white p-6 rounded-2xl shadow-lg border border-blue-200">
        <h2 class="text-2xl font-bold text-blue-800 mb-8">🚀 Bienvenido al Inicio</h2>
        <p class="text-gray-700 mb-4">Aquí puedes gestionar todas las funcionalidades de tu aplicación.</p>
        <p class="text-gray-500 text-sm">Utiliza el menú lateral para navegar entre las diferentes secciones.</p>
        <p class="text-gray-500 text-sm">Próximamente gráficos aquí!</p>
      </div>
    </div>
  </AppMain>
</template>